# GSTTimestampTest
Test program for retrieving RTSP/RTCP timestamps for each frame using GStreamer.

# Setup
So far this has been compiled and run on a Windows environment. It requires GStreamer v1.21 or greater installed, with the bin folder setup on the path. GStreamer binaries used in testing were found here: 

https://gstreamer.freedesktop.org/download/

In particular the MingW variant was used during testing.

# Running

The program will connect to a specified ip/port with a specified username/password. The latency option controls how long the rtspsrc buffers incoming packets. It has a direct impact on per-frame latency. It also has an impact on frequency of dropped image frames. The FPS option is used to correct for I-Frames which are missing timestamp information.

The program is currently setup only to work with H264 streams, although the underlying code is present for H265 or MJPEG streams.
