﻿using System;
using CommandLine;

namespace GSTTimestampTest
{
    public class Options
    {
        [Option('i', "ip", Required = false, HelpText = "IP Address of the camera.", Default ="192.168.0.120")]
        public string Ip { get; set; }

        [Option('p', "port", Required = false, HelpText = "Port of the camera.", Default = (UInt16)554)]
        public UInt16 Port { get; set; }

        [Option('u', "username", Required = false, HelpText = "Username for connecting to the camera", Default = "admin")]
        public string Username { get; set; }

        [Option('w', "password", Required = false, HelpText = "Password for connecting to the camera", Default = "admin")]
        public string Password { get; set; }

        [Option('l', "latency", Required = false, HelpText = "GStreamer buffer latency", Default = 100)]
        public int Latency { get; set; }

        [Option('f', "fps", Required = false, HelpText = "Expected stream fps (used for some internal adjustments)", Default = 30)]
        public int FPS { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Parser.Default.ParseArguments<Options>(args)
                   .WithParsed<Options>(o =>
                   {
                       RTSPGStreamerClient client = new RTSPGStreamerClient(RTSPPipelineType.H264);
                       client.Connect(o.Ip, o.Port, o.Username, o.Password, 1, o.Latency, o.FPS);
                       while (true)
                       {
                           client.UpdateConnectionStatus();
                           Thread.Sleep(50);
                       }
                   });
        }

    }
}

