﻿using GLib;
using Gst.Video;
using Gst;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NLog;

namespace GSTTimestampTest
{
    public enum RTSPClientStates
    {
        Disconnected,
        Connecting,
        Connected
    }

    public enum RTSPPipelineType
    {
        H264,
        H265,
        MJPEG
    }

    internal class RTSPGStreamerClient
    {


        private Pipeline? pipeline = null;
        private Element? rtspSrc = null;
        private Element? watchdog = null;
        private Element? depay = null;
        private Element? parse = null;
        private Element? decode = null;
        private Element? videoSink = null;
        private Element? videoconvert0 = null;
        private Element? videoqueue0 = null;
        private Element? timeOverlay = null;

        private System.DateTime lastFrameSystemTime = System.DateTime.MinValue;
        private System.DateTime lastFrameCameraTime = System.DateTime.MinValue;
        private bool isFirstFrame = true;
        private long numMissingTimestamps = 0;
        private int latency = 100;
        private int expectedFPS = 30;

        private NLog.Logger log = LogManager.GetCurrentClassLogger();

        public RTSPClientStates ClientState { get; private set; }
        public RTSPPipelineType PipelineType { get; private set; }

        public RTSPGStreamerClient(RTSPPipelineType pipelineType)
        {
            Gst.Application.Init();
            ClientState = RTSPClientStates.Disconnected;
            PipelineType = pipelineType;
        }

        public void Connect(string ip, UInt16 port, string user, string password, int streamID, int latency, int expectedFPS)
        {            
            if (pipeline == null)
            {
                this.latency = latency;
                this.expectedFPS = expectedFPS;
                string rtspURI = string.Format("rtsp://{0}:{1}@{2}:{3}/snl/live/1/{4}", user, password, ip, port, streamID);
                BuildPipeline(rtspURI);
            }
            if (pipeline != null)
            {
                ClientState = RTSPClientStates.Connecting;
                pipeline.SetState(State.Playing);
            }
        }

        public void Reconnect()
        {
            if (pipeline != null)
            {
                ClientState = RTSPClientStates.Connecting;
                pipeline.SetState(State.Playing);
            }
        }

        public void Disconnect()
        {
            if (pipeline != null)
            {
                pipeline.SetState(State.Null);
                ClientState = RTSPClientStates.Disconnected;
            }
        }

        public void DestroyPipeline()
        {
            if (pipeline != null)
            {
                pipeline = null;
            }
        }

        private void LogFailedElementCreate(string elementName, Element? elem)
        {
            if (elem == null)
            {
                log.Info($"Failed to create: {elementName}");
            }
        }

        private void BuildPipeline(string rtspURI)
        {
            log.Info("Building pipeline");
            rtspSrc = Gst.ElementFactory.Make("rtspsrc", "Source");

            if (PipelineType == RTSPPipelineType.H264)
            {
                log.Info("Building H264 decoding pipeline");
                BuildH264MidPipeline();
            }
            else if (PipelineType == RTSPPipelineType.H265)
            {
                log.Info("Building H265 decoding pipeline");
                BuildH265MidPipeline();
            }
            else if (PipelineType == RTSPPipelineType.MJPEG)
            {
                log.Info("Building MJPEG decoding pipeline");
                BuildMJPEGMidPipeline();
            }
            else
            {
                log.Info($"Unsupported pipeline type: {PipelineType}");
                return;
            }

            watchdog = Gst.ElementFactory.Make("watchdog", "Watchdog");

            videoqueue0 = Gst.ElementFactory.Make("queue", "videoqueue0");
            videoconvert0 = Gst.ElementFactory.Make("videoconvert", "videoconvert0");
            videoSink = Gst.ElementFactory.Make("fakevideosink", "nullsink"); 

            timeOverlay = Gst.ElementFactory.Make("timeoverlay", "timeoverlay");

            if (rtspSrc == null || watchdog == null || depay == null || parse == null || decode == null ||
                videoqueue0 == null || videoconvert0 == null || videoSink == null || timeOverlay == null)
            {
                log.Info("Failed to create all pipeline elements");
                LogFailedElementCreate("rtspSrc", rtspSrc);
                LogFailedElementCreate("watchdog", watchdog);
                LogFailedElementCreate("depay", depay);
                LogFailedElementCreate("parse", parse);
                LogFailedElementCreate("decode", decode);
                LogFailedElementCreate("videoqueue0", videoqueue0);
                LogFailedElementCreate("videoconvert0", videoconvert0);
                LogFailedElementCreate("videoSink", videoSink);
                LogFailedElementCreate("timeOverlay", timeOverlay);
                return;
            }

            rtspSrc["location"] = rtspURI;
            rtspSrc["latency"] = latency;
            rtspSrc["udp-reconnect"] = true;
            rtspSrc["add-reference-timestamp-meta"] = true;


            timeOverlay["time-mode"] = 5;
            timeOverlay.GetStaticPad("video_sink").AddProbe(PadProbeType.Buffer, OnTimestamp);


            // Watchdog is used here to monitor the rtspSrc for incoming buffers.
            // This appears to be the most consistent way to catch issues with the pipeline.
            watchdog["timeout"] = 10000;

            pipeline = new Pipeline("rtspPipeline");
            pipeline.Add(rtspSrc, depay, parse, decode, watchdog, videoqueue0, videoconvert0, timeOverlay, videoSink);
            if (!Pipeline.Link(depay, parse, decode, watchdog))
            {
                log.Info("Failed to link start of video pipeline");
                return;
            }
            if (!Pipeline.Link(videoqueue0, videoconvert0, timeOverlay, videoSink))
            {
                log.Info("Failed to link end of video pipeline");
                return;
            }

            if (!watchdog.Link(videoqueue0))
            {
                log.Info("Failed to link middle of pipeline");
                return;
            }

            rtspSrc.Connect("pad-added", OnRSTPSrcPadAdded);
            var ret = pipeline.SetState(State.Ready);
            log.Info("Pipeline complete");
        }


        private PadProbeReturn OnTimestamp(Pad pad, PadProbeInfo info)
        {
            ReferenceTimestampMeta rtm = info.Buffer.GetReferenceTimestampMeta();
            if (rtm.Timestamp > 0)
            {

                System.DateTime systemTime = System.DateTime.UtcNow;
                System.DateTime epochTime = new System.DateTime(1900, 1, 1, 0, 0, 0, System.DateTimeKind.Utc);
                System.DateTime camFrameTime = epochTime.AddTicks((long)rtm.Timestamp / 100);

                if (!isFirstFrame)
                {
                    var sysCameraDelta = systemTime - camFrameTime;
                    var sysFrameDelta = systemTime - lastFrameSystemTime;
                    var camFrameDelta = camFrameTime - lastFrameCameraTime;

                    log.Info("{0} => latency: {1}s, cam_delta: {2}s, sys_delta: {3}s, num_mts: {4}",
                        camFrameTime.ToString("MM/dd/yyyy hh:mm:ss.fff tt"),
                        sysCameraDelta.TotalSeconds,
                        camFrameDelta.TotalSeconds,
                        sysFrameDelta.TotalSeconds,
                        numMissingTimestamps);
                }
                isFirstFrame = false;
                lastFrameSystemTime = systemTime;
                lastFrameCameraTime = camFrameTime;
            }
            else
            {
                if (!isFirstFrame)
                {
                    numMissingTimestamps++;
                    System.DateTime systemTime = System.DateTime.UtcNow;
                    System.DateTime camFrameTime = lastFrameCameraTime + new System.TimeSpan(0, 0, 0, 0, (int)(1000 / expectedFPS));
                    var sysCameraDelta = systemTime - camFrameTime;
                    var sysFrameDelta = systemTime - lastFrameSystemTime;
                    var camFrameDelta = camFrameTime - lastFrameCameraTime;

                    log.Info("{0} => latency: {1}s, cam_delta: {2}s, sys_delta: {3}s, num_mts: {4}",
                        camFrameTime.ToString("MM/dd/yyyy hh:mm:ss.fff tt"),
                        sysCameraDelta.TotalSeconds,
                        camFrameDelta.TotalSeconds,
                        sysFrameDelta.TotalSeconds,
                        numMissingTimestamps);
                    lastFrameSystemTime = systemTime;
                    lastFrameCameraTime = camFrameTime;
                }
            }
            return PadProbeReturn.Ok;
        }
        private void BuildH264MidPipeline()
        {
            depay = Gst.ElementFactory.Make("rtph264depay", "Depay");
            parse = Gst.ElementFactory.Make("h264parse", "Parse");
            decode = Gst.ElementFactory.Make("avdec_h264", "Decode");
        }

        private void BuildH265MidPipeline()
        {
            depay = Gst.ElementFactory.Make("rtph265depay", "Depay");
            parse = Gst.ElementFactory.Make("h265parse", "Parse");
            decode = Gst.ElementFactory.Make("avdec_h265", "Decode");
        }

        private void BuildMJPEGMidPipeline()
        {
            depay = Gst.ElementFactory.Make("rtpjpegdepay", "Depay");
            parse = Gst.ElementFactory.Make("identity", "Parse");
            decode = Gst.ElementFactory.Make("jpegdec", "Decode");
        }

        private void OnRSTPSrcPadAdded(object o, SignalArgs args)
        {
            Pad depaySink = depay.GetStaticPad("sink");
            if (depaySink.IsLinked)
            {
                log.Info("RTSPSrc already linked to depay");
                return;
            }
            Pad pad = (Pad)args.Args[0];
            log.Info("Linking RTSPSrc with depay");
            if (pad.Link(depaySink) == PadLinkReturn.Ok)
            {
                log.Info("Linked RTSPSrc with depay");
            }
            else
            {
                log.Info("Failed to link RTSPSrc with depay");
            }
        }

        public void UpdateConnectionStatus()
        {
            if (pipeline != null)
            {
                var message = pipeline.Bus.Poll(MessageType.Any, 0);
                if (message != null)
                {
                    HandlePipelineMessage(message);
                    message.Dispose();
                }
            }
        }
        private void HandlePipelineMessage(Message msg)
        {
            switch (msg.Type)
            {
                case MessageType.Error:
                    GLib.GException gerror;
                    string debug;
                    msg.ParseError(out gerror, out debug);
                    if (gerror.Message == "Watchdog triggered")
                    {
                        log.Info("Stream disconnected. Watchdog triggered.");
                        Disconnect();
                    }
                    else
                    {
                        log.Info($"[Error] {gerror.Message}, debug information {debug}.");
                    }
                    break;
                case MessageType.Eos:
                    // Sometimes this gets triggered ahead of watchdog, so we check for EoS as disconnection
                    // signal
                    log.Info("Stream disconnected. End of stream");
                    Disconnect();
                    break;

                case MessageType.Progress:
                    ProgressType pt;
                    string code;
                    string text;
                    msg.ParseProgress(out pt, out code, out text);
                    if (pt == ProgressType.Complete && code == "open")
                    {
                        log.Info("Client connected. Detected via progress message");
                        ClientState = RTSPClientStates.Connected;
                    }
                    break;
            }
        }
    }

}
