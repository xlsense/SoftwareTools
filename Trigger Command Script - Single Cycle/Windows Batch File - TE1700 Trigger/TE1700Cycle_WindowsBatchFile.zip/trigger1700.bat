@echo off
setlocal enabledelayedexpansion

rem Initialize variables
set "ip="
set "username="
set "password="

echo Starting program...

rem Read the variables from the text file
for /f "tokens=1* delims==" %%a in (settings.txt) do (
    set "%%a=%%b"
)

rem Check if the variables were read successfully
if not defined ip (
    echo Error: Could not read IP from settings.txt.
    pause
    exit /b 1
)

if not defined username (
    echo Error: Could not read username from settings.txt.
    pause
    exit /b 1
)

if not defined password (
    echo Error: Could not read password from settings.txt.
    pause
    exit /b 1
)

rem Display the variables
echo IP: !ip!
echo Username: !username!
echo Password: !password!

rem Call your Python script with the extracted arguments
rem python cycle.py --ip !ip! --uname !username! --pswd !password!
cycle.exe --ip !ip! --uname !username! --pswd !password!

rem Check the exit code of the Python script
if %errorlevel% equ 1 (
    echo Python script encountered an exception. Press any key to continue...
    pause >nul
)

endlocal
